import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then((m) => m.HomePage),
  },

  {
    path: 'tabs',
    loadComponent: () => import('./tabs/tabs.page').then((m) => m.TabsPage),
    children: [
      {
        path: 'today',
        loadComponent: () => import('./pages/today/today.page').then((m) => m.TodayPage),
      },
      {
        path: 'map',
        loadComponent: () => import('./pages/map/map.page').then((m) => m.MapPage),
      },
      {
        path: 'settings',
        loadComponent: () => import('./pages/settings/settings.page').then((m) => m.SettingsPage),
      },
      { path: '', redirectTo: 'today', pathMatch: 'full' },
    ],
  },

  { path: '', redirectTo: 'home', pathMatch: 'full' },
];

